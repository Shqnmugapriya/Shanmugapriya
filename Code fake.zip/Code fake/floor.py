def solve():
    import sys
    input = sys.stdin.read
    data = input().split("\n")
    
    t = int(data[0])  # Number of test cases
    results = []
    
    for i in range(1, t + 1):
        if not data[i]:  # Skip empty lines
            continue
        
        x, n, m = map(int, data[i].split())
        
        # Compute minimum value
        min_x = x
        for _ in range(n):
            min_x //= 2
            if min_x == 0:
                break  # Once x reaches 0, further operations do nothing
        
        # Compute maximum value
        max_x = x
        for _ in range(m):
            max_x = (max_x + 1) // 2  # Ceil division
        
        for _ in range(n):
            max_x //= 2
            if max_x == 0:
                break
        
        results.append(f"{min_x} {max_x}")
    
    # Output all results at once for efficiency
    sys.stdout.write("\n".join(results) + "\n")

