import { Tracer } from "./tracer.js";
import { generateAIHint } from "./AI_helper.js";

let executionStepsDiv;
let replayButton = null; // Prevent duplicate buttons

function visualizeExecution(input, output, speed = 1000) {
    console.log("Starting visualization...");
    let tracer = new Tracer();
    let variables = {}; // Track variable changes

    executionStepsDiv = document.getElementById("execution-steps");
    if (!executionStepsDiv) {
        console.error("Error: Execution steps container not found.");
        return;
    }
    executionStepsDiv.innerHTML = ""; // Clear previous execution steps

    // Remove existing replay button
    if (replayButton && replayButton.parentNode) {
        replayButton.remove();
        replayButton = null;
    }

    // Create variable visualization section
    let variableContainer = document.createElement("div");
    variableContainer.id = "variable-container";
    executionStepsDiv.appendChild(variableContainer);

    function updateVariableDisplay() {
        variableContainer.innerHTML = "<b>Variable State:</b><br>";
        Object.entries(variables).forEach(([key, value]) => {
            let varLine = document.createElement("div");
            varLine.classList.add("variable-item"); // Use CSS for styling
            varLine.innerHTML = `<span class="var-name">${key}:</span> <span class="var-value">${value}</span>`;
            variableContainer.appendChild(varLine);
        });
    }

    function executeStep(index) {
        if (index < input.length) {
            variables[`var${index}`] = input[index];
            tracer.logStep(variables);
            updateVariableDisplay(); // Update live variable visualization

            let stepDiv = document.createElement("div");
            stepDiv.innerHTML = `<b>Step ${index + 1}:</b> Processing '<span class="highlight">${input[index]}</span>'`;
            stepDiv.classList.add("execution-step");
            executionStepsDiv.appendChild(stepDiv);

            // Smooth animation effect
            stepDiv.style.opacity = 0;
            stepDiv.style.transition = "opacity 0.5s ease-in-out";

            setTimeout(() => {
                stepDiv.style.opacity = 1;
                stepDiv.classList.add("active-step");
                executeStep(index + 1);
            }, speed);
        } else {
            // Show final output after all steps
            variables["result"] = output;
            tracer.logStep(variables);
            updateVariableDisplay(); // Show final variable state

            let outputDiv = document.createElement("div");
            outputDiv.innerHTML = `<b>Final Output:</b> <span class="highlight">${output}</span>`;
            outputDiv.classList.add("execution-step");
            executionStepsDiv.appendChild(outputDiv);

            // AI Insights - Prevent duplication
            let aiHintDiv = document.getElementById("ai-hint");
            if (!aiHintDiv) {
                aiHintDiv = document.createElement("div");
                aiHintDiv.id = "ai-hint";
                executionStepsDiv.appendChild(aiHintDiv);
            }
            aiHintDiv.innerHTML = ""; // Clear old hints
            generateAIHint(input, output);

            tracer.showSteps();

            // Add Replay Button
            addReplayButton(input, output, speed);
        }
    }

    executeStep(0); // Start execution animation
}

function addReplayButton(input, output, speed) {
    if (!replayButton) { // Prevent duplicates
        replayButton = document.createElement("button");
        replayButton.innerText = "🔄 Replay";
        replayButton.classList.add("replay-button"); // Use CSS for styling

        replayButton.addEventListener("click", () => {
            visualizeExecution(input, output, speed);
        });
    }

    if (!executionStepsDiv.contains(replayButton)) { // Prevent multiple inserts
        executionStepsDiv.appendChild(replayButton);
    }
}

export { visualizeExecution };
