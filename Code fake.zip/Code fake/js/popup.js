document.addEventListener("DOMContentLoaded", () => {
    const queryInput = document.getElementById("debug-query");
    const askButton = document.getElementById("ask-ai");
    const outputDiv = document.getElementById("output");
    const loadingDiv = document.getElementById("loading");

    if (!queryInput || !askButton || !outputDiv || !loadingDiv) {
        console.error("Required HTML elements are missing.");
        return;
    }

    askButton.addEventListener("click", handleAIRequest);
    queryInput.addEventListener("keypress", (event) => {
        if (event.key === "Enter" && !event.shiftKey) {
            event.preventDefault();
            handleAIRequest();
        }
    });

    function handleAIRequest() {
        const codeQuery = queryInput.value.trim();
        if (!codeQuery) {
            showMessage("⚠️ Please enter some code or a question.", "error");
            return;
        }

        askButton.disabled = true; // Prevent multiple clicks
        toggleLoading(true);

        try {
            chrome.runtime.sendMessage({ action: "analyzeCode", code: codeQuery }, (response) => {
                askButton.disabled = false;
                toggleLoading(false);

                if (chrome.runtime.lastError) {
                    console.error("Chrome Runtime Error:", chrome.runtime.lastError.message);
                    showMessage("Communication with background script failed.", "error");
                    return;
                }

                if (!response || response.status !== "success") {
                    showMessage(`AI Error: ${response?.message || "Unknown error"}`, "error");
                    return;
                }

                displayAIResponse(response.explanation);
            });
        } catch (error) {
            console.error("Unexpected Error:", error);
            showMessage("Unexpected error occurred.", "error");
            askButton.disabled = false;
            toggleLoading(false);
        }
    }

    function displayAIResponse(responseText) {
        outputDiv.innerHTML = `
            <strong>AI Response:</strong>
            <p id="ai-response-text" class="ai-response">${responseText}</p>
            <button id="copy-btn">Copy</button>
        `;
        applyFadeEffect(outputDiv);

        // Auto-scroll for long responses
        if (responseText.length > 500) {
            const aiResponse = document.getElementById("ai-response-text");
            aiResponse.style.maxHeight = "200px";
            aiResponse.style.overflowY = "auto";
            aiResponse.style.border = "1px solid #ccc";
            aiResponse.style.padding = "5px";
        }
    }

    outputDiv.addEventListener("click", (event) => {
        if (event.target.id === "copy-btn") {
            copyResponseToClipboard(event.target);
        }
    });

    function copyResponseToClipboard(copyBtn) {
        const responseText = document.getElementById("ai-response-text")?.innerText.trim() || "";
        if (!responseText) {
            showMessage(" Nothing to copy.", "error", true);
            return;
        }

        navigator.clipboard.writeText(responseText)
            .then(() => {
                copyBtn.textContent = " Copied!";
                setTimeout(() => (copyBtn.textContent = "Copy"), 2000);
            })
            .catch(() => showMessage(" Failed to copy text.", "error", true));
    }

    function showMessage(message, type, isTemporary = false) {
        clearPreviousMessages();

        const messageDiv = document.createElement("div");
        messageDiv.textContent = message;
        messageDiv.style.color = type === "success" ? "green" : "red";
        messageDiv.style.marginTop = "10px";

        outputDiv.appendChild(messageDiv);
        applyFadeEffect(messageDiv);

        if (isTemporary) {
            setTimeout(() => messageDiv.remove(), 2000);
        }
    }

    function clearPreviousMessages() {
        outputDiv.querySelectorAll("div").forEach((msg) => {
            if (!msg.querySelector("button") && !msg.querySelector("strong")) {
                msg.remove();
            }
        });
    }

    function toggleLoading(isLoading) {
        loadingDiv.style.display = isLoading ? "block" : "none";
        askButton.disabled = isLoading;
    }

    function applyFadeEffect(element) {
        element.style.opacity = "0";
        element.style.transition = "opacity 0.3s ease-in-out";
        requestAnimationFrame(() => (element.style.opacity = "1"));
    }
});
