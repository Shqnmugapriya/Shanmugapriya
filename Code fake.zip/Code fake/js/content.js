console.log("🚀 Codeforces AI Debugger Loaded!");

// Load Pyodide (WebAssembly Python)
async function loadPyodideAndRun(code, input) {
    if (!window.pyodide) {
        console.log("⏳ Loading Pyodide...");
        window.pyodide = await globalThis.loadPyodide();
        console.log("✅ Pyodide Loaded!");
    }

    try {
        // Inject input before execution
        window.pyodide.FS.writeFile('input.txt', input + '\n');

        let wrappedCode = `
import sys
sys.stdin = open('input.txt', 'r')
${code}
`;
        let output = await window.pyodide.runPythonAsync(wrappedCode);
        console.log("📤 Output:", output);
        showOverlay("✅ Output:\n" + output);
    } catch (error) {
        console.error("❌ Error:", error);
        showOverlay("⚠ Error:\n" + error.message);
    }
}

// Extract Python code from Codeforces editor
async function extractCodeAndRun() {
    let inputElement = document.querySelector("textarea") || document.querySelector(".input-output textarea");
    let input = inputElement ? inputElement.value.trim() : "";

    let codeMirrorInstance = document.querySelector(".CodeMirror");
    if (!codeMirrorInstance) {
        showOverlay("⚠ No Code Found!");
        return;
    }

    let cm = codeMirrorInstance.CodeMirror;
    let code = cm ? cm.getValue().trim() : "";

    if (!code) {
        showOverlay("⚠ No Python Code Detected!");
        return;
    }

    showOverlay("⏳ Running Python Code...");
    await loadPyodideAndRun(code, input);
}

// Show overlay message
function showOverlay(message) {
    let overlay = document.getElementById("ai-debugger-overlay");
    if (overlay) overlay.remove();

    overlay = document.createElement("div");
    overlay.id = "ai-debugger-overlay";
    overlay.style.position = "fixed";
    overlay.style.bottom = "20px";
    overlay.style.right = "20px";
    overlay.style.background = "white";
    overlay.style.padding = "15px";
    overlay.style.borderRadius = "8px";
    overlay.style.boxShadow = "0px 4px 10px rgba(0, 0, 0, 0.2)";
    overlay.style.maxWidth = "300px";
    overlay.style.zIndex = "1000";
    overlay.innerHTML = `
        <h4 style="margin: 0; font-size: 16px;">AI Debugger</h4>
        <p style="font-size: 14px; color: #333;">${message.replace(/\n/g, "<br>")}</p>
        <button id="close-overlay" style="margin-top: 5px; padding: 5px; border: none; background: #d9534f; color: white; cursor: pointer; border-radius: 5px;">
            Close
        </button>
    `;

    document.body.appendChild(overlay);
    document.getElementById("close-overlay").addEventListener("click", () => overlay.remove());
}

// Run when popup button is clicked
extractCodeAndRun();
