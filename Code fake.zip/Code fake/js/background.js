chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "analyzeCode") {
        console.log("🔍 AI analyzing the code...");

        // Wrap in an async function to handle async calls properly
        (async () => {
            try {
                // Ensure code is present before processing
                if (!request.code || request.code.trim() === "") {
                    console.error("⚠ No code provided for analysis.");
                    setTimeout(() => sendResponse({ status: "error", message: "No code provided for analysis." }), 0);
                    return;
                }

                // Retrieve API Key securely using a Promise
                const API_KEY = await new Promise((resolve, reject) => {
                    chrome.storage.sync.get(["apiKey"], (result) => {
                        if (chrome.runtime.lastError) {
                            reject(chrome.runtime.lastError);
                        } else {
                            resolve(result.apiKey);
                        }
                    });
                });

                if (!API_KEY) {
                    console.error("🚨 API key is missing!");
                    setTimeout(() => sendResponse({ status: "error", message: "API key not set. Please configure it in settings." }), 0);
                    return;
                }

                // Prepare the request payload
                const payload = {
                    model: "gpt-4-turbo",
                    messages: [{ role: "user", content: `Explain this code step by step:\n${request.code}` }],
                    max_tokens: 300
                };

                // Make the API request
                const response = await fetch("https://api.openai.com/v1/chat/completions", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${API_KEY}`
                    },
                    body: JSON.stringify(payload)
                });

                // Check if the response is okay
                if (!response.ok) {
                    throw new Error(`HTTP Error! Status: ${response.status}`);
                } 

                const data = await response.json();

                if (data.error) {
                    console.error("🚨 OpenAI API Error:", data.error.message);
                    setTimeout(() => sendResponse({ status: "error", message: `AI Error: ${data.error.message}` }), 0);
                    return; 
                }

                if (data.choices && data.choices.length > 0) {
                    setTimeout(() => sendResponse({ status: "success", explanation: data.choices[0].message.content }), 0);
                    return;
                }

                setTimeout(() => sendResponse({ status: "error", message: "No explanation received from AI." }), 0);

            } catch (error) {
                console.error("🚨 Unexpected error:", error);
                setTimeout(() => sendResponse({ status: "error", message: "Unexpected error occurred. Please try again." }), 0);
            }
        })();

        return true; // ✅ Ensures Chrome keeps the message channel open for async response
    }
});
