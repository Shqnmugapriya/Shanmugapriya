class Tracer {
    constructor() {
        this.steps = [];
        this.tracerContainer = document.getElementById("tracer-container");

        // If container doesn't exist, create one dynamically
        if (!this.tracerContainer) {
            this.tracerContainer = document.createElement("div");
            this.tracerContainer.id = "tracer-container";
            this.tracerContainer.style.marginTop = "15px";
            document.body.appendChild(this.tracerContainer);
        }
    }

    logStep(variables) {
        const snapshot = structuredClone(variables); // Optimized deep copy
        this.steps.push(snapshot);
    }

    showSteps() {
        if (!this.tracerContainer) return;

        this.tracerContainer.innerHTML = "<h3>Execution Trace</h3>";
        
        this.steps.forEach((step, index) => {
            let stepDiv = document.createElement("div");
            stepDiv.classList.add("tracer-step");
            stepDiv.innerHTML = `<b>Step ${index + 1}:</b> ${this.formatVariables(step)}`;

            // Smooth fade-in effect for each step
            stepDiv.style.opacity = "0";
            stepDiv.style.transition = "opacity 0.5s ease-in-out";
            this.tracerContainer.appendChild(stepDiv);

            setTimeout(() => {
                stepDiv.style.opacity = "1";
            }, index * 300); // Delay for each step
        });
    }

    formatVariables(variables) {
        return Object.entries(variables).map(([key, value]) => {
            return `<span class="var-name">${key}:</span> <span class="var-value">${value}</span>`;
        }).join(", ");
        // return Object.entries(variables)
        //     .map(([key, value]) => <span class="var-name">${key}:</span> <span class="var-value">${value}</span>)
        //     .join(", ");

    }

    reset() {
        this.steps = [];
        if (this.tracerContainer) this.tracerContainer.innerHTML = "";
    }
}

export { Tracer };
